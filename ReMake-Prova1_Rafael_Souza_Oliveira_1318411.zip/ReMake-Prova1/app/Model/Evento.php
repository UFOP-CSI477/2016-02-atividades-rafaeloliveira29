<?php 

class Evento extends AppModel{


}