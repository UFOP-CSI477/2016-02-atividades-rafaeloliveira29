<?php 

class Atleta extends AppModel{

	public $hasMany = array('Registro');

}