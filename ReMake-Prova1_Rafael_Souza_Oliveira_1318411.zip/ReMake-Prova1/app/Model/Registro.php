<?php 

class Registro extends AppModel{

	public $belongsTo = array('Atleta','Evento');

}