<?php
	echo "<h1> Dados Informados no Cadastro <h1>";
	echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"bootstrap.css\" />";
  $nome = $_GET["nome"];
	$sexo = $_GET["Sexo"];
	$rua = $_GET["Rua"];
	$numero = $_GET["Numero"];
	$complemento = $_GET["Complemento"];

	if(isset($_GET["telefone"])){
		$telefone  = "Telefone: " . $_GET["telefone"];
	}
	$celular = $_GET["celular"];
	$cep = $_GET["cep"];
	$cpf = $_GET["cpf"];
$area = "Nenhuma.";
	if(isset($_GET["WEB"])){
		$area  += "Web";
	}

	if(isset($_GET["BD"])){
		$area  = "Banco de dados";
	}

	if(isset($_GET["PROG"])){
		$area = "Programacao";
	}
	if(isset($_GET["Redes"])){
		$area = "Redes";
	}
	if(isset($_GET["Gestão"])){
		$area = "Gestão";
	}
	if(isset($_GET["IA"])){
		$area = "Inteligencia Artifical";
	}
	if(isset($_GET["algoritmos"])){
		$area = "Algoritmos";
	}
	if(isset($_GET["teoria da computação"])){
		$area = "teoria da computação";
	}
	if(isset($_GET["Inteligencia Computacional"])){
		$area = "Inteligencia Computacional";
	}

	$cidade = $_GET["cidades"];
	$estado = $_GET["estados"];
	$sex ="Nao declarado.";
	if(isset($_GET["masculno"])){
		$sex  = "Masculino: " . $_GET["Masculino"];
	}
	if(isset($_GET["feminino"])){
		$sexo  = "Feminino: " . $_GET["Feminino"];
	}
	$usuario = $_GET["usuario"];
	$senha = $_GET["senha"];
	$email = $_GET["email"];



		echo "<pre> Nome: " .$nome .
		"\n Rua: " .$rua .
"\n Numero: " .$numero .
"\n Complemento: " .$complemento .
"\n Telefone: " .$telefone .
"\n Celular: " .$celular.
"\n CEP: " .$cep.
"\n CPF: " .$cpf.
"\n Area: " .	$area.
"\n Cidade: " .$cidade .
"\n Estado: " .$estado .
"\n Sexo: " .$sex.
"\n Usuario: " .$usuario.
"\n Senha: " .$senha.
"\n Email: " .$email;
		echo "<pre>";

		echo "<a class=\"btn btn-focus btn-success\" onclick =\"alert('Dados Cadastrados com Sucesso #sqn')\" href=\"tabela.html\">Aceitar</a>";
		echo "<a class=\"btn btn-danger\" href=\"cadastro.html\" >Rejeitar</a>";

 ?>
