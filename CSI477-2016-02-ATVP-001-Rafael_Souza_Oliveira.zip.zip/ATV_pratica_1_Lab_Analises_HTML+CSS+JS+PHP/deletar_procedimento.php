           <?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);
$Id = $_POST["deletar"]; 
$sql = "DELETE FROM procedimentos WHERE id ='$Id'";
mysqli_query($conexao,$sql) or die("Erro ao tentar cadastrar DEleTAR , TENTE NOVAMENTE AA");
mysqli_close($conexao);




?>
<html>
    <head>
        </head>
        <body>
                    <H2>PROCEDIMENTO EXCLUIDO COM SUCESSO</H2>
                    <script language="javascript">
    window.location.href = "Lista_procedimentos_excluir_listar.php" 
    alert("PROCEDIMENTO EXCLUIDO COM SUCESSO!!");
</script>


            </body>
    </html>