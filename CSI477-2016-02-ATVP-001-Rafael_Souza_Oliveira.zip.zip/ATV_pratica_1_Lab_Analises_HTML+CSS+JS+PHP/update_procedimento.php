           <?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);

echo'<html>
<meta charset="utf-8">
<head>
<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<title></title>
<center>
<body style="background-color:#f2f2f2">
<nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
                <a class="navbar-brand" href="#">Area de Administrador</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="batidaponto_operador.html">Registrar Ponto</a></li>
                    <!-- so deve aparecer se o login for feito com sucesso-->
                    <li><a href="tela_inicial.html">Sair</a></li>
                </ul>
            </div>
        </div>
    </nav>
		<h1><center>Tabela de Procedimentos</h1>
			<div >
<table class="table table-reflow" align ="center">
	<thead>';
echo '<tr class="info">';
echo '<td>Id</td>';
echo '<td>Nome</td>';
echo '<td>Preço</td>';
echo '</tr>';
$result = $conexao->query('SELECT a.id,a.nome,a.preco FROM procedimentos a; ');
if($result){
    while ($row = $result->fetch_assoc()){
        echo '<tr>';
echo '<td>'.$row["id"].'</td>';
echo '<td>'.$row["nome"].'</td>';
echo '<td>'.$row["preco"].'</td>';
echo '</tr>';
      }

echo '</table>';
echo '<form action="editar_procedimento.php" method="post">
            <br> ID do Procedimento a ser Modificado: <input type="text" name="id" />
            <br> Novo Valor: <input type="text" name="valor" />
            
            <br>
            <BUTTON class="btn btn-primary" type="submit" onclick="alert("Procedimento Atualizado COm Sucesso" ");
)">Atualizar </BUTTON>
            <a class="btn btn-primary" href="procedimentos_options_operador.html">Voltar</a>
    </div>
    </form>';


    $result->free();
}
$conexao->close();


echo'  <div class="container-fluid bg-2 text-center ">
        <h3>Excelência em Análises Clínicas</h3>
        <p>Solicite todos os seus exames e resultados na comodidade da sua casa.</p>
        <h7>Todos os Direitos Reservados. Nome: Rafael Souza Oliveira. Matricula:13.1.8411</h7>
        <h7>ICEA- UFOP - João Monlevade.</h7>

    </div>'
?>
