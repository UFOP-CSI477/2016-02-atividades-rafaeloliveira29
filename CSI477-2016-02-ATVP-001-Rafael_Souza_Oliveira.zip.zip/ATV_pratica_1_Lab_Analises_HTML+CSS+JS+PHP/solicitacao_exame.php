           <?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);
$ProcedimentoId = $_POST["procedimentoid"]; 
$Login = $_POST["login"]; 
$Data = $_POST["data"]; 

$sql_counter = "SELECT *
FROM exames ";
$resultado = $conexao->query($sql_counter);
$Id=$resultado->num_rows+1;

$getID = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT id FROM pacientes WHERE login = '$Login'"));
$Paciente_Id = $getID['id'];



$sql = "INSERT INTO exames (`id`,`paciente_id`,`procedimento_id`,`data`) VALUES ('$Id','$Paciente_Id','$ProcedimentoId','$Data') ";

mysqli_query($conexao,$sql) or die("Erro ao tentar cadastrar a solicitação , TENTE NOVAMENTE ");
mysqli_close($conexao);




?>
<html>
    <head>
        </head>
        <body>
                    <H2>PROCEDIMENTO EXCLUIDO COM SUCESSO</H2>
                    <script language="javascript">
    window.location.href = "meus_exames.php" 
    alert("Solicitação Cadastrada COM SUCESSO!!");
</script>


            </body>
    </html>