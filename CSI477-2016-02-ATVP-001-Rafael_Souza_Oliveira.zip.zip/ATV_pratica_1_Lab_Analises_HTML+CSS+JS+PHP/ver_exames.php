           <?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);

echo'<html>
<meta charset="utf-8">
<head>
<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<title></title>
<center>
<body bgcolor="#f2f2f2">
<nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
                <a class="navbar-brand" href="#">Meus Exames</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="meus_exames.php">Meus Exames</a></li>
                
                    <li><a href="tela_inicial.html">Voltar</a></li>
                </ul>
            </div>
        </div>
    </nav>
		<h2><center>Tabela de Exames Disponibilizados pelo Laboratório com Seus Respectivos Valores.</h2>
			<div >
<table class="table table-reflow" align ="center">
	<thead>';
echo '<tr class="info">';
echo '<td>Nome Paciente</td>';
echo '<td> Exame</td>';
echo '<td>Data</td>';


echo '</tr>';
$Login = $_POST["login"]; 
$getID = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT id FROM pacientes WHERE login = '$Login'"));
$Paciente_Id = $getID['id'];
$result1 = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT data FROM exames WHERE paciente_id = '$Paciente_Id' Order by data ;"));
$Data = $result1['data'];


$getID1 = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT nome from pacientes where id = '$Paciente_Id'"));
$Paciente_nome = $getID1['nome'];



$getID2 = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT procedimento_id from exames where paciente_id = '$Paciente_Id'"));
$procedimento_Id = $getID2['procedimento_id'];
$result3 = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT nome FROM procedimentos WHERE id = '$procedimento_Id' ;"));
$nome_procedimento = $getID2['nome'];



$result = $conexao->query("SELECT a.nome,b.nome as nomeexame,c.data from pacientes a INNER JOIN procedimentos b INNER JOIN exames c where a.nome = '$Paciente_nome' AND b.nome = '$nome_procedimento' AND c.data = '$Data'
");
echo "ESTOU AQUI";


if($result){
    while ($row = $result->fetch_assoc()){
        echo '<tr>';
echo '<td>'.$row["nome"].'</td>';
echo '<td>'.$row["nomeexame"].'</td>';
echo '<td>'.$row["data"].'</td>';

echo '</tr>';
}
echo '</table>';


    $result->free();
}


#if($result){
 #  while ($row = mysqli_fetch_array($result1)){
  #      echo '<tr>';
   #     echo '<td>'.$row["nome"].'</td>';
    #}

     # while ($row = mysqli_fetch_array($result2)){
       
#echo '<td>'.$row["nome"].'</td>';
#}
 #    while ($row = mysqli_fetch_array($result)){

#echo '<td>'.$row["data"].'</td>';
#echo '</tr>';
 #   }
   
 

     
#echo '</table>';


 #   $result->free();
#}
#$conexao->close();
echo '
           <a class="btn btn-primary btn-sm" href="tela_inicial_logado_paciente.html ">Voltar</a>
    </div>
    </form>';
echo'  
<div class="container-fluid bg-2 text-center ">
        <h3>Excelência em Análises Clínicas</h3>
        <p>Solicite todos os seus exames e resultados na comodidade da sua casa.</p>
        <h7>Todos os Direitos Reservados. Nome: Rafael Souza Oliveira. Matricula:13.1.8411</h7>
        <h7>ICEA- UFOP - João Monlevade.</h7>

    </div>'
?>
