<?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);

	 

$Nome = $_POST["nome"]? addslashes(trim($_POST["nome"])) : FALSE; ;
$Login = $_POST["login"] ? addslashes(trim($_POST["login"])) : FALSE;;
$Senha = $_POST["senha"] ? addslashes(trim($_POST["senha"])) : FALSE;;

$sql_counter = "SELECT *
FROM pacientes ";

$resultado = $conexao->query($sql);
$id=$resultado->num_rows+1;


$sql = "INSERT INTO 'pacientes' (`id`, `nome`, `login`, `senha`) VALUES ";
$sql .= "('$Id', '$Nome', '$Login','$Senha')"; 


$sql = "INSERT INTO pacientes VALUES ";
$sql .= "('$Id', '$Nome', '$Login','$Senha')"; 
mysqli_query($conexao,$sql) or die("Erro ao tentar cadastrar SEUS DADOS , TENTE NOVAMENTE");
mysqli_close($conexao);
header( 'Location: tela_inicial.html') ;


?>
