<?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);


$Nome        	= $_POST["nome"];
$Preco        		= $_POST["preco"];


$Usuario_id = 1;

echo $nome . $preco . $Usuario_id;

	$sql_counter = "SELECT *
FROM procedimentos ";

$resultado = $conexao->query($sql);
$id=$resultado->num_rows+1;



$sql = "INSERT INTO `procedimentos`(`id`, `nome`, `preco`, `usuario_id`) VALUES  ";
$sql .= "('$Id', '$Nome', '$Preco','$Usuario_id')"; 

mysqli_query($conexao,$sql)or die("Erro ao tentar registrar o procedimento , TENTE NOVAMENTE");
mysqli_close($conexao);
echo "<script>
alert('PROCEDIMENTO Registrado com Sucesso!!!');
window.location.href='novo_procedimento.html'
</script>";

