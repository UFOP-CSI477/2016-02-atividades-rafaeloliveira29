<?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);



$Nome = $_POST["nome"]; 
$Login = $_POST["login"];
$Senha = $_POST["senha"];
$Tipo = $_POST["tipo"];



$sql = "INSERT INTO `usuarios`(`id`, `nome`, `login`, `senha`, `tipo`) VALUES ";
$sql .= "('$id', '$Nome', '$Login','$Senha','$Tipo')"; 


mysqli_query($conexao,$sql) or die("Erro ao tentar cadastrar SEUS DADOS , TENTE NOVAMENTE AA");
mysqli_close($conexao);

header( 'Location: novo_funcionario.html') ;


?>
