           <?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);

$result = $conexao->query('SELECT a.id, a.nome,a.preco FROM procedimentos a Order by a.id; ');
echo'<html>
<meta charset="utf-8">
<head>
<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<title></title>
<center>
<body style="background-color:#f2f2f2">
<nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
                <a class="navbar-brand" href="#">Meus Exames</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="meus_exames.php">Meus Exames</a></li>
                
                    <li><a href="tela_inicial_logado_paciente.html">Voltar</a></li>
                </ul>
            </div>
        </div>
    </nav>
		<h2><center>Tabela de Exames Disponibilizados pelo Laboratório com Seus Respectivos Valores.</h2>
			<div >
<table class="table table-reflow" align ="center">
	<thead>';
echo '<tr class="info">';
echo '<td>Id</td>';
echo '<td>Nome</td>';
echo '<td>Preço</td>';


echo '</tr>';

if($result){
    while ($row = $result->fetch_assoc()){
        echo '<tr>';
echo '<td>'.$row["id"].'</td>';
echo '<td>'.$row["nome"].'</td>';
echo '<td>'.$row["preco"].'</td>';
echo '</tr>';
     
}
echo '</table>';


    $result->free();
}
$conexao->close();
echo '<form action="ver_exames.php" method="post">
            <br> Insira seu Login para verificar exames disponiveis: <input type="text" name="login" value ="Seu Login" />
            
            
            
            <br>
            <BUTTON class="btn btn-primary" type="submit" onclick="alert("Exame Solicitado COm Sucesso, VErifique na Guia "MEUS EXAMES" a sua solicitação. " ");
)">Ver Exames </BUTTON>
           <a class="btn btn-primary btn-sm" href="tela_inicial_logado_paciente.html ">Voltar</a>
    </div>
    </form>';
echo'  
<div class="container-fluid bg-2 text-center ">
        <h3>Excelência em Análises Clínicas</h3>
        <p>Solicite todos os seus exames e resultados na comodidade da sua casa.</p>
        <h7>Todos os Direitos Reservados. Nome: Rafael Souza Oliveira. Matricula:13.1.8411</h7>
        <h7>ICEA- UFOP - João Monlevade.</h7>

    </div>'
?>

   