<?php

$SERVER = "localhost";
$USERNAME = "sisanalise";
$PASSWORD = "123456";
$DATABASE = "analise";
