-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jan 29, 2017 at 06:01 AM
-- Server version: 5.6.28
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `analise`
--

-- --------------------------------------------------------

--
-- Table structure for table `exames`
--

CREATE TABLE `exames` (
  `id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `procedimento_id` int(11) NOT NULL,
  `data` varchar(10) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `exames`
--

INSERT INTO `exames` (`id`, `paciente_id`, `procedimento_id`, `data`) VALUES
(1, 5, 1, '12-12-12'),
(2, 2, 3, '10-11-2012'),
(3, 2, 3, '10-11-2012'),
(4, 2, 3, '10-11-2012'),
(6, 48, 21, '12-01-2016'),
(7, 48, 21, '12-01-2016');

-- --------------------------------------------------------

--
-- Table structure for table `pacientes`
--

CREATE TABLE `pacientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `login` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(10) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `pacientes`
--

INSERT INTO `pacientes` (`id`, `nome`, `login`, `senha`) VALUES
(1, 'Maria Silva', 'silva', '4620'),
(2, 'José Santos', 'santos', '4298'),
(3, 'Antônio Oliveira', 'oliveira', '4631'),
(4, 'João Souza', 'souza', '3262'),
(5, 'Francisco Pereira', 'pereira', '3415'),
(6, 'Ana Costela', 'costela', '4291'),
(7, 'Luiz Carvalho', 'carvalho', '4211'),
(8, 'Paulo Almeida', 'almeida', '3181'),
(9, 'Carlos Ferreira', 'ferreira', '4272'),
(10, 'Manoel Ribeiro', 'ribeiro', '4817'),
(11, 'Pedro Rodrigues', 'rodrigues', '4270'),
(12, 'Francisca Gomes', 'gomes', '3898'),
(13, 'Marcos Lima', 'lima', '3683'),
(14, 'Raimundo Martins', 'martins', '3723'),
(15, 'Sebastião Rocha', 'rocha', '4563'),
(16, 'Antônia Alves', 'alves', '4649'),
(17, 'Marcelo Araújo', 'araujo', '4557'),
(18, 'Jorge Xavier', 'xavier', '3837'),
(19, 'Márcia Barbosa', 'barbosa', '4516'),
(20, 'Geraldo Castro', 'castro', '4069'),
(21, 'Adriana Fernandes', 'fernandes', '3796'),
(22, 'Sandra Melo', 'melo', '3773'),
(23, 'Luis Azevedo', 'azevedo', '4477'),
(24, 'Fernando Barros', 'barros', '4070'),
(48, 'Rafael', 'rafael', '1234'),
(51, 'Res', 'aas', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `ponto`
--

CREATE TABLE `ponto` (
  `id` int(11) NOT NULL,
  `login` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `obs` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `data` varchar(20) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `ponto`
--

INSERT INTO `ponto` (`id`, `login`, `obs`, `data`) VALUES
(0, 'joaoadmin', 'rasadas', '27-01-2017 12:34:46'),
(0, '', '', '27-01-2017 12:45:44'),
(0, '', '', '27-01-2017 12:46:03'),
(0, 'dasa', 'sdadas', '27-01-2017 12:54:50'),
(0, 'joaoadmin', 'saa', '27-01-2017 12:56:59'),
(0, 'joaoadmin', 'saa', '27-01-2017 12:57:46'),
(0, 'joaoadmin', 'asdasdasds', '27-01-2017 12:58:24'),
(0, 'joaoadmin', 'sdadsada', '27-01-2017 13:11:21'),
(0, 'joaoadmin', 'sadasd', '27-01-2017 13:18:30'),
(0, 'joaoadmin', 'DSADAS', '27-01-2017 13:19:42'),
(0, 'joaoadmin', '', '27-01-2017 22:01:47');

-- --------------------------------------------------------

--
-- Table structure for table `procedimentos`
--

CREATE TABLE `procedimentos` (
  `id` int(11) NOT NULL,
  `nome` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `usuario_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `procedimentos`
--

INSERT INTO `procedimentos` (`id`, `nome`, `preco`, `usuario_id`) VALUES
(1, 'Exame De Vista', '3.22', 1),
(3, 'exame', '122321.00', 1),
(21, 'exame', '12.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `login` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `tipo` varchar(1) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `login`, `senha`, `tipo`) VALUES
(1, 'Joao', 'joaoadmin', '123', '1'),
(3, 'Rfaeç', 'rafaadmin', 'a', '1'),
(4, 'Maria', 'mariaop', '123', '2'),
(6, '1', '1', '1', '1'),
(7, '1', '1', '1', '1'),
(8, '1', '1', '1', '1'),
(9, '1', '1', '1', '1'),
(10, '', '', '', ''),
(11, 'teste', 'teste', 'teste', '2'),
(12, 'Joaoa', 'joaoaadmin', '123', '1'),
(17, 'Rafael11', 'aadmin', 'a123', '1'),
(18, 'Rafael11', 'aadmin', 'a123', '1'),
(19, 'raaa', 'raaaop', '123', '2'),
(20, 'raaa', 'raaaop', '123', '2'),
(21, 'Maria', 'joaaooop', '123', '2'),
(22, 'rasad', 'sssss', 'aaaaa', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exames`
--
ALTER TABLE `exames`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_exames_has_procedimentos` (`procedimento_id`),
  ADD KEY `idx_exames_has_pacientes` (`paciente_id`);

--
-- Indexes for table `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `procedimentos`
--
ALTER TABLE `procedimentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_procedimentos_usuarios1_idx` (`usuario_id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exames`
--
ALTER TABLE `exames`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `procedimentos`
--
ALTER TABLE `procedimentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `exames`
--
ALTER TABLE `exames`
  ADD CONSTRAINT `fk_exames_has_pacientes` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_exames_has_procedimentos` FOREIGN KEY (`procedimento_id`) REFERENCES `procedimentos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `procedimentos`
--
ALTER TABLE `procedimentos`
  ADD CONSTRAINT `fk_procedimentos_usuarios1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
