<?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);



// Recupera o login
$login = isset($_POST["usuario"]) ? addslashes(trim($_POST["usuario"])) : FALSE;
// Recupera a senha, a criptografando em MD5
$senha = isset($_POST["senha"]) ? (trim($_POST["senha"])) : FALSE;#podia passar MD5 mas não


/**
* Executa a consulta no banco de dados.
* Caso o número de linhas retornadas seja 1 o login é válido,
* caso 0, inválido.
*/
$sql = "SELECT *
FROM pacientes WHERE login = '$login' AND senha = '$senha'";

$resultado = $conexao->query($sql);
if($resultado->num_rows ==1){
	echo "Login realizado com sucesso!! REDIRECIONANDO....";
	echo "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=tela_inicial_logado_paciente.html'>";
}
else{
	echo "<script>
alert('LOGIN OU SENHA INVÁLIDOS...FAVOR TENTAR NOVAMENTE');
window.location.href='tela_inicial.html';
</script>";

}

?>
