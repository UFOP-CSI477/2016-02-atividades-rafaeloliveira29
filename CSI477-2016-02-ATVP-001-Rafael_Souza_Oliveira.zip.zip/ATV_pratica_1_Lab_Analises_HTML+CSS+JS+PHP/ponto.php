<?php
// Conexão com o banco de dados
/**
 * PDO - Conexão com a base de dados - Aula 28
 * http://www.todoespacoonline.com/w/2014/07/23/pdo-em-php/
 */
require_once("config.php");
	 $conexao = new mysqli($SERVER,$USERNAME,$PASSWORD,$DATABASE);


$login        	= $_POST["login"];
$obs        		= $_POST["obs"];
$data = date('d-m-Y');
    $data .= ' '.date('H:i:s');


$sql = "SELECT *
FROM usuarios WHERE login = '$login'";

$resultado = $conexao->query($sql);
if($resultado->num_rows ==1){
	$sql_counter = "SELECT *
FROM ponto ";

$resultado = $conexao->query($sql);
$id=$resultado->num_rows+1;



$sql = "INSERT INTO `ponto`(`id`, `login`, `obs`, `data`) VALUES  ";
$sql .= "('$Id', '$login', '$obs','$data')"; 

mysqli_query($conexao,$sql)or die("Erro ao tentar registrar o ponto , TENTE NOVAMENTE");
mysqli_close($conexao);
echo "<script>
alert('Ponto Registrado com Sucesso!!! TENHA UM BOM DIA DE TRABALHO');
window.location.href='area_admin.html'
</script>";

}
else if($resultado->num_rows ==0)
{
    echo "<script>
alert('LOGIN INEXISTENTE NO BANCO DE DADOS...FAVOR TENTAR NOVAMENTE');
window.location.href='batidaponto.html';
</script>";
}





?>
    
    